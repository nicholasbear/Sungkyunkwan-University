var num=0;
let list=[];
list.length=12;

function checkImage(url) { // check image exists
  var image = new Image();
  image.onload = function() {
    if (this.width > 0) {
      console.log("image exists");
    }
  }
  image.onerror = function() {
    alert("image doesn't exist");
  }
  image.src = url;
}

// function to add list to local storage
function addToLocalStorage(list) {
  // conver the array to string then store it.
  localStorage.setItem('list', JSON.stringify(list));
  // render them to screen
  renderTodos(list);
}

//putting information to screen
function renderTodos(list) {
  if(list[8]!=null){   //show 3tasks
    console.log("You went to 3");
    num=3;
    $("#one img").attr("src",list[0]);
    $("#one h3").text(list[1]);
    $("#one p").text(list[2]);
    $("#one span").text(list[3]);
    $("#two img").attr("src",list[4]);
    $("#two h3").text(list[5]);
    $("#two p").text(list[6]);
    $("#two span").text(list[7]);
    $("#three img").attr("src",list[8]);
    $("#three h3").text(list[9]);
    $("#three p").text(list[10]);
    $("#three span").text(list[11]);

    $("#one").show();
    $("#two").show();
    $("#three").show();
  }
  else if(list[4]!=null){ //show 2tasks
    console.log("You went to 2");
    num=2;
    $("#one img").attr("src",list[0]);
    $("#one h3").text(list[1]);
    $("#one p").text(list[2]);
    $("#one span").text(list[3]);
    $("#two img").attr("src",list[4]);
    $("#two h3").text(list[5]);
    $("#two p").text(list[6]);
    $("#two span").text(list[7]);

    $("#one").show();
    $("#two").show();
    $("#three").hide();

  }
  else if(list[0]!=null){ //show 1task
    console.log("You went to 1");
    num=1;
    $("#one img").attr("src",list[0]);
    $("#one h3").text(list[1]);
    $("#one p").text(list[2]);
    $("#one span").text(list[3]);

    $("#one").show();
    $("#two").hide();
    $("#three").hide();

  }
  else if(list[0]==null){//no task written
    console.log("You went to 0");
    num=0;
    $("#one").hide();
    $("#two").hide();
    $("#three").hide();

  }
  console.log(num);
  console.log(list[8]);
  console.log(list[4]);
  console.log(list[0]);

}

// function helps to get everything from local storage
function getFromLocalStorage() {
  const reference = localStorage.getItem('list');
  // if reference exists
  console.log(reference);
  if (reference) {
    // converts back to array and store it in list array
    temp1 = JSON.parse(reference);
    renderTodos(temp1);
  }
}

$(document).ready(function(){

  $(".add-button").click(function(){// when we click add button
    $(".newtask").css("box-shadow", "0 0 0 100vmax rgba(0,0,0,0.6)");
    $(".newtask").show();
    $(".image-url").val("");   //init
    $(".task-title").val("");
    $(".task-type").val("");
    $(".task-description").val("");
  });

  $("#x-button").click(function(){//when we click x button
    $(".newtask").css("box-shadow","none");
    $(".newtask").hide();
  });

  $(".close").click(function(){//when we click close button
    $(".newtask").css("box-shadow","none");
    $(".newtask").hide();
  });

  $(".save-changes").click(function(){ //when we click save button
    checkImage($(".image-url").val()); //checking if image exists
    const temp={    //make information object
      img: $(".image-url").val(),
      title:$(".task-title").val(),
      type:$(".task-type").val(),
      description:$(".task-description").val()
    };
    //by numbers input information in each div
    if(num==0){
      list[0]=temp.img;
      list[1]=temp.title;
      list[2]=temp.type;
      list[3]=temp.description;
      addToLocalStorage(list);
    }
    else if(num==1){
      list[4]=temp.img;
      list[5]=temp.title;
      list[6]=temp.type;
      list[7]=temp.description;
      addToLocalStorage(list);
    }
    else if(num==2){
      list[8]=temp.img;
      list[9]=temp.title;
      list[10]=temp.type;
      list[11]=temp.description;
      addToLocalStorage(list);
    }
    else{
      alert("you addend too much!")
    }
    $(".newtask").hide();
  });

  $("#trash1").click(function(){ //when we click first trash
    if(num==2){ //if there 2tasks
      list[0]=list[4]; list[1]=list[5];list[2]=list[6];list[3]=list[7];//move list2 information to list1
      list[4]=null; list[5]=null; list[6]=null; list[7]=null;//empty list2
      addToLocalStorage(list);
    }
    else if(num==3){ // 3tasks
      list[0]=list[4]; list[1]=list[5];list[2]=list[6];list[3]=list[7];//move list2 information to list1
      list[4]=list[8]; list[5]=list[9];list[6]=list[10];list[7]=list[11];//move list3 information to list2
      list[8]=null; list[9]=null; list[10]=null; list[11]=null;//empty list3
      addToLocalStorage(list);
    }
    else{
      list[0]=null; list[1]=null; list[2]=null; list[3]=null;
      addToLocalStorage(list);
    }
  });

  $("#trash2").click(function(){ //when we click second trash
    if(num==3){
      list[4]=list[8]; list[5]=list[9];list[6]=list[10];list[7]=list[11];//move list3 information to list2
      list[8]=null; list[9]=null; list[10]=null; list[11]=null;//empty list3
      addToLocalStorage(list);
    }
    else if(num==2){
      list[4]=null; list[5]=null; list[6]=null; list[7]=null;//empty list2
      addToLocalStorage(list);
    }
  });

  $("#trash3").click(function(){ //when we click third trash
    list[8]=null; list[9]=null; list[10]=null; list[11]=null;//empty list3
    addToLocalStorage(list);
  });
});


getFromLocalStorage();//get information from local localStorage
