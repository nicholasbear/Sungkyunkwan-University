#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 29 13:33:24 2022
@author: hsherlcok
"""

import math
import random
from site import USER_SITE
import time
from flask import Flask
from flask import request
from flask import jsonify

# This line is for solving flask's CORS error
# You need 'pip install flask_cors' to use flask_cors
#from flask_cors import CORS
from werkzeug.serving import WSGIRequestHandler
import json
WSGIRequestHandler.protocol_version = "HTTP/1.1"

app = Flask(__name__)

# This line is for solving flask's CORS error
#CORS(app)

global users
global pi
users = [0,0]

@app.route("/monte-carlo/pi", methods=['GET'])
def make_pi():
    n = int(request.args.get('n'))
    
    print(n)
    count =0
    start = time.time()
    for i in range(n):
        x = random.uniform(0,1)
        y = random.uniform(0,1)
        if x*x + y*y <= 1:
            count +=1
    global pi
    pi = (count / n) *4

    end = time.time()
    
    global users
    users[0] = end - start
    users[1] = pi
    
    ret = {}
    ret["elapse time"] = users[0]
    ret["pi"] = users[1]
    
    # return jsonify(maze=string.decode('utf-8', 'ignore'))
    return jsonify (ret)

@app.route("/get/pi", methods=['GET'])
def get_pi():
    global users
    ret = {}
    global pi
    ret["pi"] = pi
    
    # return jsonify(maze=string.decode('utf-8', 'ignore'))
    return jsonify (ret)

@app.route("/update/pi", methods=['POST'])
def update_name():
    content = request.get_json(silent=True)
    global pi
    pi = content["pi"]
    if not pi:
        return jsonify(success=False)
    global users
    users[1] = pi
    
    return jsonify(success=True)
    
if __name__ == "__main__":
    app.run(host='localhost', port=8888)