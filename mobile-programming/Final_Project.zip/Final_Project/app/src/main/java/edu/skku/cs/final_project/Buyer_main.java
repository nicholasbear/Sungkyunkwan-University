package edu.skku.cs.final_project;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.ArrayList;

public class Buyer_main extends AppCompatActivity implements MySimpleContract.ContractForView{
    private GridView gridview;
    private Drink_ListAdapter drink_listAdapter;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private ImageView button5;
    private ImageView button6;
    private MySimplePresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer_main);

        button1 = findViewById(R.id.Whisky);
        button2 = findViewById(R.id.Cocktail);
        button3 = findViewById(R.id.Beer);
        button4 = findViewById(R.id.Food);
        button5 = findViewById(R.id.home);
        button6 = findViewById(R.id.cart);
        presenter = new MySimplePresenter(this, new MySimpleModel());

        button1.setTextColor(Color.parseColor("#F8C471"));
        presenter.Button_getBuyer("Whisky");

        button1.setOnClickListener(view -> {
            button1.setTextColor(Color.parseColor("#F8C471"));
            button2.setTextColor(Color.parseColor("#000000"));
            button3.setTextColor(Color.parseColor("#000000"));
            button4.setTextColor(Color.parseColor("#000000"));
            presenter.Button_getBuyer("Whisky");
        });

        button2.setOnClickListener(view -> {
            button1.setTextColor(Color.parseColor("#000000"));
            button2.setTextColor(Color.parseColor("#F8C471"));
            button3.setTextColor(Color.parseColor("#000000"));
            button4.setTextColor(Color.parseColor("#000000"));
            presenter.Button_getBuyer("Cocktail");
        });

        button3.setOnClickListener(view -> {
            button1.setTextColor(Color.parseColor("#000000"));
            button2.setTextColor(Color.parseColor("#000000"));
            button3.setTextColor(Color.parseColor("#F8C471"));
            button4.setTextColor(Color.parseColor("#000000"));
            presenter.Button_getBuyer("Beer");
        });

        button4.setOnClickListener(view -> {
            button1.setTextColor(Color.parseColor("#000000"));
            button2.setTextColor(Color.parseColor("#000000"));
            button3.setTextColor(Color.parseColor("#000000"));
            button4.setTextColor(Color.parseColor("#F8C471"));
            presenter.Button_getBuyer("Food");
        });

        button5.setOnClickListener(view -> {
            presenter.Goto_Main(view);
        });

        button6.setOnClickListener(view -> {
            Context context = view.getContext();
            Intent intent = new Intent (context, Cart.class);
            startActivity(intent);
        });
    }

    @Override
    public void Adapt(ArrayList<Item> ALL){
        (Buyer_main.this).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                gridview = findViewById(R.id.drink_list);
                drink_listAdapter = new Drink_ListAdapter(Buyer_main.this, ALL);
                gridview.setAdapter(drink_listAdapter);
            }
        });
    }
}