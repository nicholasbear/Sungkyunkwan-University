package edu.skku.cs.final_project;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.GridView;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

public class MySimplePresenter implements MySimpleContract.ContractForPresenter{
    private MySimpleContract.ContractForView view;
    private MySimpleContract.ContractForModel model;
    JSONArray ItemArray;
    JSONObject ItemObject;
    private ArrayList<Item> ALL;


    public MySimplePresenter(MySimpleContract.ContractForView view, MySimpleContract.ContractForModel model){
        this.view = view;
        this.model = model;
    }

    @Override
    public void Button_getBuyer(final String category) {
        model.getList_Buyer(new MySimpleContract.ContractForModel.onFinished_Listener() {
            @Override
            public void onFinished(String myResponse) {
                try {
                    ItemArray = new JSONArray(myResponse);
                    ALL = new ArrayList<Item>();
                    for(int i = 0 ; i < ItemArray.length();i++){
                        ItemObject = ItemArray.getJSONObject(i);
                        if(ItemObject.getString("category").equals(category)) {
                            Item temp = new Item();
                            temp.setName(ItemObject.getString("name"));
                            temp.setPrice(ItemObject.getInt("price"));
                            temp.setUrl(ItemObject.getString("url"));
                            temp.setCategory(ItemObject.getString("category"));
                            temp.setNum(ItemObject.getInt("num"));
                            ALL.add(temp);
                        }
                    }
                    view.Adapt(ALL);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void Button_getCart() {
        model.getList_Cart(new MySimpleContract.ContractForModel.onFinished_Listener() {
            @Override
            public void onFinished(String myResponse) {
                try {
                    ItemArray = new JSONArray(myResponse);
                    ALL = new ArrayList<Item>();
                    for(int i = 0 ; i < ItemArray.length();i++){
                        ItemObject = ItemArray.getJSONObject(i);
                        Item temp = new Item();
                        temp.setName(ItemObject.getString("name"));
                        temp.setPrice(ItemObject.getInt("price"));
                        temp.setUrl(ItemObject.getString("url"));
                        temp.setCategory(ItemObject.getString("category"));
                        temp.setNum(ItemObject.getInt("num"));
                        ALL.add(temp);
                    }
                    view.Adapt(ALL);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void Button_getSeller() {
        model.getList_Buyer(new MySimpleContract.ContractForModel.onFinished_Listener() {
            @Override
            public void onFinished(String myResponse) {
                try {
                    ItemArray = new JSONArray(myResponse);
                    ALL = new ArrayList<Item>();
                    for(int i = 0 ; i < ItemArray.length();i++){
                        ItemObject = ItemArray.getJSONObject(i);
                        Item temp = new Item();
                        temp.setName(ItemObject.getString("name"));
                        temp.setPrice(ItemObject.getInt("price"));
                        temp.setUrl(ItemObject.getString("url"));
                        temp.setCategory(ItemObject.getString("category"));
                        temp.setNum(ItemObject.getInt("num"));
                        ALL.add(temp);
                    }
                    view.Adapt(ALL);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    public void Goto_Main(View view){
        model.Goto_Main(view);
    }
}