package edu.skku.cs.final_project;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MySimpleModel implements MySimpleContract.ContractForModel{
    private ArrayList<Item> ALL;
    private Drink_ListAdapter drink_listAdapter;

    public MySimpleModel(){
    }

    @Override
    public void getList_Buyer(final onFinished_Listener onFinished_listener){
        OkHttpClient client = new OkHttpClient();
        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/list").newBuilder();
        String url = urlBuilder.build().toString();
        Request req = new Request.Builder()
                .url(url)
                .build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();
                onFinished_listener.onFinished(myResponse);
            }
        });
    }

    @Override
    public void getList_Cart(final onFinished_Listener onFinished_listener){
        OkHttpClient client = new OkHttpClient();
        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/cart").newBuilder();
        String url = urlBuilder.build().toString();
        Request req = new Request.Builder()
                .url(url)
                .build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();
                onFinished_listener.onFinished(myResponse);
            }
        });
    }

    @Override
    public void Goto_Main(View view){
        Context context = view.getContext();
        Intent intent = new Intent (context, MainActivity.class);
        context.startActivity(intent);
        OkHttpClient client = new OkHttpClient();
        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/init").newBuilder();
        String url = urlBuilder.build().toString();
        Request req = new Request.Builder()
                .url(url)
                .build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                final String myResponse = response.body().string();
            }
        });
    }

}