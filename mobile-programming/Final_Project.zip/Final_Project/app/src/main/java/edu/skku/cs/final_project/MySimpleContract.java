package edu.skku.cs.final_project;

import android.content.Context;
import android.view.View;
import android.widget.GridView;
import android.widget.ListView;

import org.json.JSONArray;

import java.util.ArrayList;

public interface MySimpleContract {
    interface ContractForView{
        void Adapt(ArrayList<Item> ALL);
    }

    interface ContractForModel{
        interface onFinished_Listener{
            void onFinished(String response);
        }
        void getList_Buyer(final onFinished_Listener onFinished_listener);
        void getList_Cart(final onFinished_Listener onFinished_listener);
        void Goto_Main(View view);
    }

    interface ContractForPresenter{
        void Button_getBuyer(final String category);
        void Button_getCart();
        void Button_getSeller();
        void Goto_Main(View view);
    }
}
