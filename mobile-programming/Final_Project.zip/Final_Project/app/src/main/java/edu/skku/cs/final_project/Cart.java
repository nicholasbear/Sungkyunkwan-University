package edu.skku.cs.final_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Cart extends AppCompatActivity implements MySimpleContract.ContractForView{
    private Cart_ListAdapter cart_listAdapter;
    private ListView listview;
    private Button Order;
    public TextView Price;
    private MySimplePresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        Order = findViewById(R.id.Order_button);
        Price = findViewById(R.id.price);
        presenter = new MySimplePresenter(this, new MySimpleModel());

        presenter.Button_getCart();

        Order.setOnClickListener(view -> {
            Toast.makeText(Cart.this,"Got order",Toast.LENGTH_SHORT).show();
            presenter.Goto_Main(view);
        });
    }

    @Override
    public void Adapt(ArrayList<Item> ALL){
        (Cart.this).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                listview = findViewById(R.id.cart_list);
                Price = findViewById(R.id.price);
                cart_listAdapter = new Cart_ListAdapter(Cart.this, ALL, Price);
                listview.setAdapter(cart_listAdapter);
            }
        });
    }
}