package edu.skku.cs.final_project;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Cart_ListAdapter extends BaseAdapter {
    private final Context mContext;
    private ArrayList<Item> items;
    private Cart_ListAdapter cart_listAdapter;
    private TextView priceView;
    private ImageView imageView;
    private TextView nameView;
    private Button Plus;
    private Button Minus;
    private Integer Price;

    public Cart_ListAdapter(Context mContext, ArrayList<Item> items, TextView priceView){
        this.mContext = mContext;
        this.items = items;
        this.priceView = priceView;
        this.Price = 0;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int i) {
        return items.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.cart_list, viewGroup, false);
        }
        Activity activity = (Activity) mContext;

        imageView = view.findViewById(R.id.cart_image);
        nameView = view.findViewById(R.id.cart_name);
        final TextView Num = (TextView) view.findViewById(R.id.cart_num);
        Plus = view.findViewById(R.id.plus_button);
        Minus = view.findViewById(R.id.minus_button);
        nameView.setText(items.get(i).name);
        Num.setText(items.get(i).num.toString());
        String imgurl = items.get(i).url;
        Context context = view.getContext();
        Glide.with(context)
                .load(imgurl)
                .error(R.drawable.bar_photo)
                .into(imageView);


        OkHttpClient client1 = new OkHttpClient();
        HttpUrl.Builder urlBuilder1 = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/calculate").newBuilder();
        String url1 = urlBuilder1.build().toString();
        Request req1 = new Request.Builder()
                .url(url1)
                .build();

        client1.newCall(req1).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                Gson gson = new GsonBuilder().create();
                final String myResponse = response.body().string();
                Success tf = gson.fromJson(myResponse, Success.class);
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        priceView.setText(tf.getSuccess()+ "원");
                    }
                });
            }
        });

        Plus.setOnClickListener(v->{
            OkHttpClient client = new OkHttpClient();
            HttpUrl.Builder urlBuilder = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/plus").newBuilder();
            Gson gson = new Gson();
            Name name = new Name();
            name.setName(items.get(i).name);
            String json = gson.toJson(name,Name.class);
            String url = urlBuilder.build().toString();
            Request req = new Request.Builder()
                    .url(url)
                    .post(RequestBody.create(MediaType.parse("application/json"),json))
                    .build();

            client.newCall(req).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    e.printStackTrace();
                }
                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    final String myResponse = response.body().string();
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Integer temp = Integer.parseInt(Num.getText().toString());
                            temp += 1;
                            Num.setText(temp.toString());
                            OkHttpClient client = new OkHttpClient();
                            HttpUrl.Builder urlBuilder = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/calculate").newBuilder();
                            String url = urlBuilder.build().toString();
                            Request req = new Request.Builder()
                                    .url(url)
                                    .build();

                            client.newCall(req).enqueue(new Callback() {
                                @Override
                                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                                    e.printStackTrace();
                                }
                                @Override
                                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                                    Gson gson = new GsonBuilder().create();
                                    final String myResponse = response.body().string();
                                    Success tf = gson.fromJson(myResponse, Success.class);
                                    activity.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            priceView.setText(tf.getSuccess() + "원");
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        });

        Minus.setOnClickListener(v->{
            Integer new_temp = Integer.parseInt(Num.getText().toString());
            if (new_temp > 0) {
                OkHttpClient client = new OkHttpClient();
                HttpUrl.Builder urlBuilder = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/minus").newBuilder();
                Gson gson = new Gson();
                Name name = new Name();
                name.setName(items.get(i).name);
                String json = gson.toJson(name, Name.class);
                String url = urlBuilder.build().toString();
                Request req = new Request.Builder()
                        .url(url)
                        .post(RequestBody.create(MediaType.parse("application/json"), json))
                        .build();

                client.newCall(req).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        final String myResponse = response.body().string();
                        activity.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Integer temp = Integer.parseInt(Num.getText().toString());
                                temp -= 1;
                                Num.setText(temp.toString());
                                OkHttpClient client = new OkHttpClient();
                                HttpUrl.Builder urlBuilder = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/calculate").newBuilder();
                                String url = urlBuilder.build().toString();
                                Request req = new Request.Builder()
                                        .url(url)
                                        .build();

                                client.newCall(req).enqueue(new Callback() {
                                    @Override
                                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                                        e.printStackTrace();
                                    }
                                    @Override
                                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                                        Gson gson = new GsonBuilder().create();
                                        final String myResponse = response.body().string();
                                        Success tf = gson.fromJson(myResponse, Success.class);
                                        activity.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                priceView.setText(tf.getSuccess() + "원");
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
            else{
                Toast.makeText(mContext,"Number can't go below 0",Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }
}
