package edu.skku.cs.final_project;

class Item {
    public String name;
    public Integer price;
    public String url;
    public String category;
    public Integer num;

    public String getName() {
        return name;
    }

    public Integer getNum() {
        return num;
    }

    public Integer getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }

    public String getUrl() {
        return url;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
