package edu.skku.cs.final_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Seller_main extends AppCompatActivity implements MySimpleContract.ContractForView{
    private Button Add_button;
    private Button Delete_button;
    private Button button;
    private ImageView home;
    private LinearLayout Add;
    private ListView Delete;
    private EditText text_name;
    private EditText text_url;
    private EditText text_price;
    private EditText text_category;
    private MySimplePresenter presenter;
    private Delete_ListAdapter delete_listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_main);

        Add_button = findViewById(R.id.Add_drink);
        Delete_button = findViewById(R.id.Delete_Drink);
        button = findViewById(R.id.add_button);
        home = findViewById(R.id.home);
        Add = findViewById(R.id.add_list);
        text_name = findViewById(R.id.name);
        text_url = findViewById(R.id.url);
        text_price = findViewById(R.id.price);
        text_category = findViewById(R.id.category);
        Delete = findViewById(R.id.delete_list);
        presenter = new MySimplePresenter(this, new MySimpleModel());

        Delete_button.setTextColor(Color.parseColor("#F8C471"));
        Add.setVisibility(View.INVISIBLE);
        Delete.setVisibility(View.VISIBLE);
        presenter.Button_getSeller();

        Add_button.setOnClickListener(view -> {
            Add_button.setTextColor(Color.parseColor("#F8C471"));
            Delete_button.setTextColor(Color.parseColor("#000000"));
            Add.setVisibility(View.VISIBLE);
            Delete.setVisibility(View.INVISIBLE);
        });

        Delete_button.setOnClickListener(view -> {
            Add_button.setTextColor(Color.parseColor("#000000"));
            Delete_button.setTextColor(Color.parseColor("#F8C471"));
            Add.setVisibility(View.INVISIBLE);
            Delete.setVisibility(View.VISIBLE);
            presenter.Button_getSeller();
        });

        button.setOnClickListener(view->{
            OkHttpClient client = new OkHttpClient();
            HttpUrl.Builder urlBuilder = HttpUrl.parse("https://n6ou3y6dwl.execute-api.ap-northeast-2.amazonaws.com/dev/adddrink").newBuilder();
            Gson gson = new Gson();
            Item temp = new Item();
            temp.setName(text_name.getText().toString());
            temp.setNum(0);
            temp.setCategory(text_category.getText().toString());
            temp.setUrl(text_url.getText().toString());
            temp.setPrice(Integer.parseInt(text_price.getText().toString()));
            String json = gson.toJson(temp,Item.class);
            String url = urlBuilder.build().toString();
            Request req = new Request.Builder()
                    .url(url)
                    .post(RequestBody.create(MediaType.parse("application/json"),json))
                    .build();

            client.newCall(req).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    e.printStackTrace();
                }
                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    Gson gson = new GsonBuilder().create();
                    final String myResponse = response.body().string();
                    Log.d("tf",myResponse);
                    Success tf = gson.fromJson(myResponse, Success.class);
                    Seller_main.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(tf.getSuccess().equals("true")) {
                                Toast.makeText(Seller_main.this, "Added!", Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(Seller_main.this, "Error!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            });
        });

        home.setOnClickListener(view -> {
            presenter.Goto_Main(view);
        });
    }

    @Override
    public void Adapt(ArrayList<Item> ALL){
        (Seller_main.this).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Delete = findViewById(R.id.delete_list);
                delete_listAdapter = new Delete_ListAdapter(Seller_main.this, ALL);
                Delete.setAdapter(delete_listAdapter);
            }
        });
    }
}
