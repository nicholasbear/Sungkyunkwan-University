package edu.skku.cs.final_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button Buyer;
    Button Seller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Buyer = findViewById(R.id.buyer_button);
        Seller = findViewById(R.id.seller_button);

        Buyer.setOnClickListener(view -> {
            Context context = view.getContext();

            Intent intent = new Intent (context, Buyer_main.class);
            startActivity(intent);
        });

        Seller.setOnClickListener(view -> {
            Context context = view.getContext();

            Intent intent = new Intent (context, Seller_main.class);
            startActivity(intent);
        });
    }
}