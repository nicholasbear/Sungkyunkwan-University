package edu.skku.MAP.week7;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    Button button;
    TextView textView1, textView2;
    private String res;
    private String answer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        button = findViewById(R.id.button);


        button.setOnClickListener(view -> {
            OkHttpClient client = new OkHttpClient();

            String input = textView1.getText().toString();

            HttpUrl.Builder urlBuilder = HttpUrl.parse("https://gn9y01tofh.execute-api.ap-northeast-2.amazonaws.com/dev/access").newBuilder();
            urlBuilder.addQueryParameter("name",input);

            String url = urlBuilder.build().toString();

            Request req = new Request.Builder().url(url).build();

            client.newCall(req).enqueue(new Callback() {
                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                    final String myResponse = response.body().string();
                    res = myResponse.substring(1,myResponse.length()-2);

                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            OkHttpClient client1 = new OkHttpClient();

                            HttpUrl.Builder urlBuilder1 = HttpUrl.parse("http://api.weatherstack.com/current").newBuilder();
                            urlBuilder1.addQueryParameter("access_key","4fa3ca69dafd43c07ee02580e69788e2");
                            urlBuilder1.addQueryParameter("query",res);

                            String url1 = urlBuilder1.build().toString();
                            Log.d("hello","haa");

                            Request req1 = new Request.Builder().url(url1).build();

                            client1.newCall(req1).enqueue(new Callback() {
                                @Override
                                public void onFailure(@NonNull Call call, @NonNull IOException e) {
                                    e.printStackTrace();
                                }

                                @Override
                                public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                                    final String myResponse2 = response.body().string();
                                    Gson gson = new GsonBuilder().create();
                                    try {
                                        JSONObject jsonObject = new JSONObject(myResponse2);

                                        answer ="Name : "+jsonObject.getJSONObject("location").getString("name").toString()+
                                                "\nTemperature :"+jsonObject.getJSONObject("current").getString("temperature").toString()+
                                                "\nWeather_descriptions :"+jsonObject.getJSONObject("current").getString("weather_descriptions").toString()+
                                                "\nhumidity :"+ jsonObject.getJSONObject("current").getString("humidity").toString();
                                    }catch (JSONException e){
                                        e.printStackTrace();
                                    }

                                    MainActivity.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            textView2.setText(answer);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        });
    }
}