package edu.skku.MAP.week7;

public class DataModel {
   private String current;

   public String getCurrent() {
      return current;
   }

   public void setCurrent(String current) {
      this.current = current;
   }
}
